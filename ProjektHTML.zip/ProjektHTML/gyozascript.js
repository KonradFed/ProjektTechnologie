   window.onload = function()
   {
       var slideShow = document.getElementById("slideShow");
     
       var imagesSrc = ["gyoza.jpeg", "gyoza1.jpeg", "gyoza2.jpeg"];
       
       for (var i = 0; i < imagesSrc.length; i++)
       {
           var image = new Image();
           
           image.src = "image/" + imagesSrc[i];
           
           slideShow.appendChild(image);
       }
       
       slideShow.childNodes[0].setAttribute("class", "current");
       var i = 0;
       
       setInterval(function()
       {
           slideShow.childNodes[i % imagesSrc.length].setAttribute("class", "");
           
           slideShow.childNodes[(i+1) % imagesSrc.length].setAttribute("class", "current");
           
           i++;
           
       }, 5000);
   };
   
   
   
   
   
   
   
   
   
   
   
   
   
   