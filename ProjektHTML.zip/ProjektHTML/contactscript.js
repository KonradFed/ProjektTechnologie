document.getElementById('submit1').addEventListener('click', function(e){
    let name = document.getElementById('name').value;
    let surname = document.getElementById('surname').value;
    let number = document.getElementById('number').value;
    let email = document.getElementById('email').value;
    let message = document.getElementById('message').value;
 
   let nameChars = /^[A-Z][A-Za-z]{0,16}$/;
   let surnameChars = /^[A-Z][A-Za-z]{0,16}$/;
   let  numberChars = /[0-9]{9}/;
   let  emailChars = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
   let  messageChars = /[a-zA-Z0-9]{1,250}/;


    if(!name.match(nameChars)){
        alert("Nieprawidłowe imię");
        e.preventDefault();
    }
    else if(!surname.match(surnameChars)){
        alert("Nieprawidłowe nazwisko");
        e.preventDefault();
    }
    else if(!number.match(numberChars)){
        alert("Nieprawidłowy numer telefonu");
        e.preventDefault();
    }
    else if(!email.match(emailChars)){
        alert("Nieprawidłowy email");
        e.preventDefault();
    }
    else if(!message.match(messageChars)){
        alert("Nieprawidłowa wiadomość");
        e.preventDefault();
    }
    else{
        alert("Wiadomość wysłana");
    } 
});