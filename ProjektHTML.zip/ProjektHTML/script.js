document.getElementById('submit1').addEventListener('click', function(e){
    var username = document.getElementById('username').value;
    var password = document.getElementById('password').value;
 
    passwdChars = /(?=.*\d)(?=.*[!@#$%\^&*)(+=._-])(?=.*[A-Z]).{6,}/g;
    userChars = /^[a-zA-Z0-9]{1,20}$/;

    if(!username.match(userChars) || !password.match(passwdChars)){
        alert("Nieprawidłowy login lub hasło!");
        e.preventDefault();
    }
});